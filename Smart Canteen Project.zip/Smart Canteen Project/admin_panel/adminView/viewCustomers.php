<div >
  <h2>All Customers</h2>
  <table class="table ">
    <thead>
      <tr>
        <!-- <th class="text-center">S.N.</th> -->
        <th class="text-center">ID </th>
        <th class="text-center">Username </th>
        <th class="text-center">Email</th>
        <th class="text-center">Contact Number</th>
        <!-- <th class="text-center">Joining Date</th> -->
        <th class="text-center">password</th>
      </tr>
    </thead>
    <?php
      // include_once "connection.php";
      include_once ('C:\xampp\htdocs\Smart Canteen Project\connection.php');
      // include_once "../config/dbconnect.php";
      $sql="SELECT * from users";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
           
    ?>
    <tr>
      <td><?=$row["id"]?> </td>
      <td><?=$row["username"]?> </td>
      <td><?=$row["email"]?></td>
      <td><?=$row["mobile"]?></td>
      <td><?=$row["password"]?></td>
      
    </tr>
    <?php
            $count=$count+1;
           
        }
    }
    ?>
  </table>
</div>


<!-- line 26 - first_name , $row["last_name"] -->
<!-- contact_no -->