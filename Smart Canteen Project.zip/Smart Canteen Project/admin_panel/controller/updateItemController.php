<?php
    // include_once "../config/dbconnect.php";
    include_once ('C:\xampp\htdocs\Smart Canteen Project\connection.php');

    $p_id=$_POST['p_id'];
    $p_name= $_POST['p_name'];
    $p_desc= $_POST['p_desc'];
    $p_price= $_POST['p_price'];
    $category= $_POST['category'];


    if( isset($_FILES['newImage']) && $_FILES['newImage']['error'] == UPLOAD_ERR_OK) {
        
        $location="./uploads/";
        $img = $_FILES['newImage']['name'];
        $tmp = $_FILES['newImage']['tmp_name'];
        $dir = '../uploads/';
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        $valid_extensions = array('jpeg', 'jpg', 'png', 'gif','webp');

        // Generate a unique filename
        $image =rand(1000,1000000).".".$ext;
        $final_image=$location. $image;

        // Move the uploaded file to the destination directory
        if (in_array($ext, $valid_extensions)) {
            $path = UPLOAD_PATH . $image;
            move_uploaded_file($tmp, $dir.$image);
        }
    }else{
        // If no new image is uploaded, use the existing image path
        $final_image=$_POST['existingImage'];
    }
    $updateItem = mysqli_query($conn,"UPDATE items SET 
        product_name='$p_name', 
        product_desc='$p_desc', 
        product_image='$final_image', 
        price=$p_price,
        category_id=$category
        
        WHERE product_id=$p_id");


    if($updateItem)
    {
        echo "true";
    }
    // else
    // {
    //     echo mysqli_error($conn);
    // }
?>