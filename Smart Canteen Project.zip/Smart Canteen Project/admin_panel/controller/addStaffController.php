<?php
    Include the database connection file
    include_once ('C:\xampp\htdocs\Smart Canteen Project\connection.php');

    // Check if form is submitted
    if(isset($_POST['submit'])) {
        // Retrieve form data
        $staff_name = $_POST['staff_name'];
        $staff_email = $_POST['staff_email'];
        $staff_address = $_POST['staff_address'];
        $staff_phone = $_POST['staff_phone'];
        $staff_category = $_POST['staff_category'];

        // SQL query to insert staff data into the database
        $insert_query = "INSERT INTO staff1 (staff_name, staff_email, staff_address, staff_phone, staff_category) 
                         VALUES ('$staff_name', '$staff_email', '$staff_address', '$staff_phone', '$staff_category')";

        // Execute the query
        if(mysqli_query($conn, $insert_query)) {
            echo "Staff added successfully.";
        } else {
            echo "Error: " . $insert_query . "<br>" . mysqli_error($conn);
        }

        // Close the database connection
        mysqli_close($conn);
    }
?>

<!-- HTML Form for adding staff -->
<div class="container">
    <h2>Add New Staff</h2>
    <form action="" method="POST">
        <div class="form-group">
            <label for="staff_name">Staff Name:</label>
            <input type="text" class="form-control" name="staff_name" required>
        </div>
        <div class="form-group">
            <label for="staff_email">Staff Email:</label>
            <input type="email" class="form-control" name="staff_email" required>
        </div>
        <div class="form-group">
            <label for="staff_address">Staff Address:</label>
            <input type="text" class="form-control" name="staff_address" required>
        </div>
        <div class="form-group">
            <label for="staff_phone">Staff Phone:</label>
            <input type="text" class="form-control" name="staff_phone" required>
        </div>
        <div class="form-group">
            <label for="staff_category">Staff Category:</label>
            <select class="form-control" name="staff_category" required>
                <option value="cook">Cook</option>
                <option value="waiter">Waiter</option>
                <option value="cashier">Cashier</option>
                <option value="manager">Manager</option>
                <option value="cleaner">Cleaner</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary" name="submit">Add Staff</button>
    </form>
</div> 






