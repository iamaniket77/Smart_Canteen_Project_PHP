<?php
    // include_once "../config/dbconnect.php";
    include_once ('C:\xampp\htdocs\Smart Canteen Project\connection.php');
    
    if(isset($_POST['upload']))
    {   
       
        $catname = $_POST['c_name'];
       
         $insert = mysqli_query($conn,"INSERT INTO categories
         (category_name) 
         VALUES ('$catname')");
            
         if($insert)
         {
             echo "Records added successfully.";
             header("Location: ../index.php");
         }
         else
         {
            echo mysqli_error($conn);
            header("Location: ../dashboard.php?category=error");
         }
    }      
?>