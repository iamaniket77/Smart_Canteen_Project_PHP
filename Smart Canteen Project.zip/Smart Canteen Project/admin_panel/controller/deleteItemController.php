<?php

    // include_once "../config/dbconnect.php";
    include_once ('C:\xampp\htdocs\Smart Canteen Project\connection.php');


    
    $p_id=$_POST['record'];
    $query="DELETE FROM items where product_id='$p_id'";

    $data=mysqli_query($conn,$query);

    if($data){
        echo"Product Item Deleted";
    }
    else{
        echo"Not able to delete";
    }
    
?>