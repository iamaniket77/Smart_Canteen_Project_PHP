document.getElementById('payment-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Simulating a payment process (replace this with actual payment processing code)
    setTimeout(function() {
      document.getElementById('message').textContent = 'Payment successful!';
    }, 2000);
  });
  