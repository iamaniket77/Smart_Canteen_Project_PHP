//-------------------------------------------making moveable cursor-------------------------------
var crsr = document.querySelector("#cursor")
var blur = document.querySelector("#cursor-blur")

document.addEventListener("mousemove",function(dets){
    crsr.style.left = dets.x + "px"
    crsr.style.top = dets.y + "px"

    blur.style.left = dets.x - 140 +"px"
    blur.style.top = dets.y - 140 +"px"
})
//-----------------------------------------------------------------------------------------------

//---------------------------------------nav cursor change happens here---------------------------
var h4all = document.querySelectorAll("#nav h4")
h4all.forEach(function(elem){
    elem.addEventListener("mouseenter",function(){
        crsr.style.scale = 3
        crsr.style.border = "1px solid #fff"
        crsr.style.backgroundColor = "transparent"
    })

    elem.addEventListener("mouseleave",function(){
        crsr.style.scale = 1
        crsr.style.border = "0px solid #95C11E"
        crsr.style.backgroundColor = "#95C11E"
    })
})

//-----------------------------------------------------------------------------------------------

//--------------------------------------------Nav Scroll trigger---------------------------------
gsap.to("#nav",{
    backgroundColor :"#000",
    height:"110px",
    duration:0.5,
    scrollTrigger:{
        trigger:"#nav",
        scroller:"body",
        // markers:true,
        start :"top -10%",
        end: "top -11",
        scrub:1  //it makes everything works on scroll basis(it can be either true or values{1 or 2 or 3})
    }
})

gsap.to("#main",{
    backgroundColor : "#000",
    scrollTrigger:{
        trigger:"#main",
        scroller:"body",
        // markers:true,
        start:"top -25%",
        end:"top -70%",
        scrub:2,
    }
})
//-----------------------------------------------------------------------------------------------

//--------------------------------------------Nav Scroll trigger---------------------------------
gsap.from("#about-us img,#about-us-in",{
    y:90,
    opacity:0,
    duration:1,
    //stagger:0.4,     //it is used to play from multiple element, play one element after another
    scrollTrigger:{         //it is use to play element when scroll at particular area
        trigger:"#about-us",
        scroller:"body",
        // marker:true,
        start:"top 70%",
        end:"top 65%",
        scrub:1
    }
})

//--------------------------------------------crad Scroll trigger---------------------------------

gsap.from(".card",{
    scale:0.8,
    opacity:0,
    duration:1,
    stagger:0.1,     //it is used to play from multiple element, play one element after another
    scrollTrigger:{         //it is use to play element when scroll at particular area
        trigger:".card",
        scroller:"body",
        // marker:true,
        start:"top 70%",
        end:"top 65%",
        scrub:1
    }
})

//--------------------------------------------colon Scroll trigger---------------------------------
gsap.from("#colon1",{
    y:-70,
    x:-70,
    scrollTrigger:{
        trigger:"#colon1",
        scroller:"body",
        // marker:true,
        start:"top 55%",
        end:"top 45%",
        scrub:4
    }
})

gsap.from("#colon2",{
    y:70,
    x:70,
    scrollTrigger:{
        trigger:"#colon1",
        scroller:"body",
        // marker:true,
        start:"top 55%",
        end:"top 45%",
        scrub:4
    }
})
//--------------------------------------------------------------------------------------------------
gsap.from("#page4 h1",{
    y:50,
    scrollTrigger:{
        trigger:"#page4 h1",
        scroller:"body",
        // marker:true,
        start:"top 75%",
        end:"top 70%",
        scrub:3
    }
})

//-----------------------------------ADD TO CART PAGE FNUCTION-------------------
// function addToCart(itemName, itemPrice) {
//     let cart = localStorage.getItem('cart') ? JSON.parse(localStorage.getItem('cart')) : [];
//     let item = { name: itemName, price: itemPrice };
//     cart.push(item);
//     localStorage.setItem('cart', JSON.stringify(cart));
//     window.location.href = 'cart.html'; // Redirect to cart page
// }
//--------------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', function () {
    displayCartItems();
});

function displayCartItems() {
    let cart = localStorage.getItem('cart') ? JSON.parse(localStorage.getItem('cart')) : [];
    let cartItemsElement = document.getElementById('cart-items');
    let totalAmountElement = document.getElementById('total-amount');
    let totalAmount = 0;

    cartItemsElement.innerHTML = '';

    cart.forEach(item => {
        let itemElement = document.createElement('div');
        itemElement.classList.add('cart-item');
        itemElement.textContent = `${item.name} - Rs ${item.price}`;
        cartItemsElement.appendChild(itemElement);

        totalAmount += item.price;
    });

    totalAmountElement.textContent = totalAmount;
}

function clearCart() {
    localStorage.removeItem('cart');
    document.getElementById('cart-items').innerHTML = '';
    document.getElementById('total-amount').textContent = '0';
}
