<?php

// Connect to the database
include_once('connection.php');



$staff_name = $_POST['staff_name'];
$staff_password = $_POST['staff_password'];
$staff_role = $_POST['staff_role'];

$sql = "INSERT INTO staff (staff_name, staff_password, staff_role) VALUES ('$staff_name', '$staff_password', '$staff_role')";

if ($conn->query($sql) === TRUE) {
    echo "New staff member added successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


// ----------------------------------------Fetch data from the database table

$sql = "SELECT staff_id, staff_name, staff_role,staff_password FROM staff";
$result = $conn->query($sql);


$data = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$conn->close();

// Return the data as JSON
echo json_encode($data);
?>
div id="ordersBtn" >
  <h2>Order Details</h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>staff_id</th>
        <th>staff_name</th>
        <th>staff_role</th>
        <th>staff_password</th>
     </tr>
    </thead>
     <?php
      include_once "connection.php";
      include_once "staff.html";
      $sql="SELECT * from staff";
      $result=$conn-> query($sql);
      
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
       <tr>
          <td><?=$row["staff_id"]?></td>
          <td><?=$row["staff_name"]?></td>
          <td><?=$row["staff_role"]?></td>
          <td><?=$row["staff_password"]?></td>
        </tr>
    <?php
       $conn->close();
    
    }
      }
    ?>