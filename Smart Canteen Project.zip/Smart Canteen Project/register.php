<?php

// include_once('connection.php');

// // Retrieve form data
// $username = $_POST['username'];
// $email = $_POST['email'];
// $mobile = $_POST['mobile'];
// $password = $_POST['password'];
// // $confirm_password = $_POST['confirm_password'];

// // Hash the password for security
// $hashed_password = password_hash($password, PASSWORD_DEFAULT);

// // Insert data into database
// $sql = "INSERT INTO users (username, email, mobile, password) VALUES ('$username', '$email', '$mobile', '$password')";

// // if ($conn->query($sql) === TRUE) {
// //     echo "Registration successful!";
// // } else {
// //     echo "Error: " . $sql . "<br>" . $conn->error;
// // }


//     if ($conn->query($sql) === TRUE) {
//         echo "Registration successful! <a href='login.html'><button>Login</button></a>";
//     } else {
//         echo "Error: " . $sql . "<br>" . $conn->error;
// }



// $conn->close();
?>

<?php
include_once('connection.php');

// Retrieve form data
$username = $_POST['username'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Server-side validations
$errors = [];
if (empty($username) || !isValidUsername($username)) {
    $errors[] = "Invalid username.";
}
if (empty($email) || !isValidEmail($email)) {
    $errors[] = "Invalid email address.";
}
if (empty($mobile) || !isValidMobile($mobile)) {
    $errors[] = "Invalid mobile number.";
}
if (empty($password) || !isValidPassword($password)) {
    $errors[] = "Invalid password.";
}
if ($password !== $confirm_password) {
    $errors[] = "Passwords do not match.";
}

if (!empty($errors)) {
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
} else {
    // Insert data into database
    $sql = "INSERT INTO users (username, email, mobile, password) VALUES ('$username', '$email', '$mobile', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful! <a href='login.html'><button>Login</button></a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();

// Server-side validation functions
function isValidUsername($username) {
    $regex = '/^[a-zA-Z0-9_-]{3,20}$/';
    return preg_match($regex, $username);
}

function isValidEmail($email) {
    $regex = '/^[^\s@]+@[^\s@]+\.[^\s@]+$/';
    return preg_match($regex, $email);
}

function isValidMobile($mobile) {
    $regex = '/^[0-9]{10}$/';
    return preg_match($regex, $mobile);
}

function isValidPassword($password) {
    $regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';
    return preg_match($regex, $password);
}
?>

