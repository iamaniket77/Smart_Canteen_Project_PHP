<?php
// // Establish database connection
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "smart_canteen";

// $conn = new mysqli($servername, $username, $password, $dbname);

// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// // Retrieve form data
// $username = $_POST['username'];
// $password = $_POST['password'];

// // Check if user exists in the database
// $sql = "SELECT * FROM users WHERE username='$username'";
// $result = $conn->query($sql);

// if ($result->num_rows > 0) {
//     $row = $result->fetch_assoc();
//     // if (password_verify($password, $row['password'])) {
//     if ($password === $row['password']) {
//         echo "Login successful!";

//         header("Location: index.html"); // Redirect to index.html page
//         exit(); // Make sure to exit after the redirect

//     } else {
//         echo "Invalid password!";
//     }
// } else {
//     echo "User not found!";
// }

// $conn->close();
?>

<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smart_canteen";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$username = $_POST['username'];
$password = $_POST['password'];

// Check if user exists in the database
$sql = "SELECT * FROM users WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $hashed_password = $row['password'];

    // Verify the hashed password
    if (password_verify($password, $hashed_password)) {
        echo "Login successful!";
        header("Location: index.html"); // Redirect to index.html page
        exit(); // Make sure to exit after the redirect
    } else {
        echo "Invalid password!";
    }
} else {
    echo "User not found!";
}

$conn->close();
?>
