-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Jul 28, 2024 at 09:13 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_canteen`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `username`, `password`) VALUES
(1, 'anya@gmail.com', 'admin'),
(3, 'admin', 'admin'),
(4, 'admin2', 'admin2');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(255) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` int(255) NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `quantity` int(255) NOT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `name`, `price`, `image`, `quantity`, `product_id`) VALUES
(55, 'coco cola', 40, './uploads/food-5.png', 2, NULL),
(56, 'French Fries', 90, './uploads/food-6.png', 1, NULL),
(57, 'fries', 78, './uploads/food-6.png', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(1, 'lunch'),
(2, 'break'),
(4, 'dinner'),
(6, 'brunch'),
(7, 'refreshment');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'aniket', 'aniket@gmail.com', 'appreciation', 'nice taste', '2024-04-28 17:26:50'),
(2, 'aniket', 'aniket@gmail.com', 'heyy', 'helo', '2024-04-28 17:36:12'),
(3, 'aniket', 'aniket@gmail.com', 'heyy', 'hello', '2024-04-28 17:39:41'),
(4, 'aniket', 'aniket@gmail.com', 'heyy', 'acassa', '2024-04-28 17:40:57'),
(5, 'aniket', 'aniket@gmail.com', 'heyy', 'hiiii', '2024-04-28 17:54:56'),
(6, 'aniket', 'aniket@gmail.com', 'heyy', 'miiii', '2024-04-28 18:17:25');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `uploaded_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`product_id`, `product_name`, `product_desc`, `product_image`, `price`, `category_id`, `uploaded_date`) VALUES
(8, 'coco cola', 'chilled', './uploads/food-5.png', 40, 2, '2024-04-11'),
(9, 'French Fries', 'hot', './uploads/food-6.png', 90, 2, '2024-04-11'),
(26, 'burger', 'delicious', './uploads/food-1.png', 85, 1, '2024-04-12'),
(28, 'bread Sandwich', 'vegies', './uploads/food-3.png', 100, 1, '2024-04-12'),
(29, 'fries', 'nice', './uploads/food-6.png', 78, 0, '2024-04-12'),
(30, 'pizza', 'nice', './uploads/food-2.png', 100, 1, '2024-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `method` varchar(100) NOT NULL,
  `flat` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `pin_code` int(10) NOT NULL,
  `total_products` varchar(255) NOT NULL,
  `total_price` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `name`, `number`, `email`, `method`, `flat`, `street`, `city`, `state`, `country`, `pin_code`, `total_products`, `total_price`, `created_at`) VALUES
(1, 'aniket', '7998978', 'anna@gmail.com', 'cash on delivery', 'anld', 'sdbak', 'bskaj', 'danjksd', 'india', 444444, 'idli (1) , poha (1) , upma (1) ', '1060', '2024-04-28 17:51:32'),
(2, 'aniket', '4546', 'adadga@gmail.com', 'credit cart', 'lane 1', 'near hdfc bank', 'mumbai', 'maharashtra', 'india', 464845, 'dosa (2) , goku (1) , chaii (1) , pohe (1) ', '175', '2024-04-28 17:51:32'),
(3, 'asvc', '468442', 'sfsfe@gmail.com', 'paypal', 'agrwa', 'qefEV', 'FAFSA', 'WRGWV', 'tjtg', 5435, 'dosa (2) , goku (1) , chaii (1) , pohe (1) ', '175', '2024-04-28 17:51:32'),
(6, 'asvc', '468442', 'sfsfe@gmail.com', 'cash on delivery', 'agrwa', 'qefEV', 'FAFSA', 'WRGWV', 'tjtg', 5435, 'large latte (2) , custurd ice (5) , kachori (1) , fry (1) ', '1005', '2024-04-28 17:51:32'),
(7, 'aniket', '4864454579', 'adadga@gmail.com', 'credit cart', 'lane 1', 'near hdfc bank', 'mumbai', 'maharashtra', 'India', 464845, 'large latte (2) , fries (1) , kachori (1) ', '963', '2024-04-28 17:51:32'),
(44, 'aniket', '4984986546', 'adadga@gmail.com', 'cash on delivery', 'lane 1', 'near hdfc bank', 'mumbai', 'maharashtra', 'India', 464845, 'misal (1) , large latte (2) , kachori (1) , fries (3) , milk (2) ', '491', '2024-04-28 17:51:32');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `staff_role` enum('cook','waiter','manager') NOT NULL,
  `staff_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_name`, `staff_role`, `staff_password`) VALUES
(1, 'john', 'cook', '4545'),
(2, 'john', 'cook', '4545'),
(3, 'moon', 'waiter', '111'),
(5, 'meww', 'waiter', '1313'),
(70, 'beyblade', 'manager', '54646');

-- --------------------------------------------------------

--
-- Table structure for table `staff1`
--

CREATE TABLE `staff1` (
  `staff_id` int(11) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `staff_email` varchar(255) NOT NULL,
  `staff_address` varchar(255) NOT NULL,
  `staff_phone` varchar(20) NOT NULL,
  `staff_category` enum('cook','waiter','cashier','manager','cleaner') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff1`
--

INSERT INTO `staff1` (`staff_id`, `staff_name`, `staff_email`, `staff_address`, `staff_phone`, `staff_category`) VALUES
(1, 'anya', 'anyaan@gmail.com', 'agra', '4645345', 'manager');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `mobile`, `password`, `created_at`) VALUES
(1, 'anya', 'anya@gmail.com', '1212', '$2y$10$uLBf7M7Aiqhj/Zaq31e9zOlD74CzmOG7EGAIojxwaPvAF8U8WMiFK', '0000-00-00 00:00:00'),
(3, 'ani1', 'ani1@gmail.com', '13131', '$2y$10$6qYqEl20UxmIcR5QYWs/ZuhTnCoDtaFCStkvcLGQ3HjLeM58jGoLi', '0000-00-00 00:00:00'),
(21, 'anna2', 'anna2@gmail.com', '4949', 'anna2', '0000-00-00 00:00:00'),
(35, 'aniket11', 'singhs4@gamil.com', '9271608447', '$2y$10$IgsictezEkSLH0Qe8A.9pORUt8qdD1wHH6gEIvmiIMNRAvYlC.dh.', '2024-06-01 20:05:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `staff1`
--
ALTER TABLE `staff1`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogin`
--
ALTER TABLE `adminlogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `staff1`
--
ALTER TABLE `staff1`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
