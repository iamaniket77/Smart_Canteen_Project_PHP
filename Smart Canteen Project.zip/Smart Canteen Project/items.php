<?php
// Connect to the database
include_once('connection.php');

// Add item
if (isset($_POST['add_item'])) {
    $category_id = $_POST['category_id'];
    $item_name = $_POST['item_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $sql = "INSERT INTO items (category_id, name, description, price, image) VALUES ('$category_id', '$item_name', '$description', '$price', '$image')";
    if ($conn->query($sql) === TRUE) {
        echo "Item added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <div>
            <h2>Add Item</h2>
            <form method="post">
                Category ID: <input type="number" name="category_id" required><br>
                Item Name: <input type="text" name="item_name" required><br>
                Description: <textarea name="description"></textarea><br>
                Price: <input type="text" name="price" required><br>
                Image URL: <input type="text" name="image"><br>
                <input type="submit" name="add_item" value="Add Item">
            </form>
        </div>
</body>
</html>







