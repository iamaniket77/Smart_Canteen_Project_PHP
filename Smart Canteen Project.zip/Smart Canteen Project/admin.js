// Code to dynamically load categories into select options
document.addEventListener('DOMContentLoaded', () => {
    // Assume categories is an array of category objects fetched from the database
    let categories = [
        { id: 1, name: 'Category 1' },
        { id: 2, name: 'Category 2' },
        // Add more categories as needed
    ];

    let categorySelect = document.getElementById('categorySelect');

    categories.forEach(category => {
        let option = document.createElement('option');
        option.value = category.id;
        option.textContent = category.name;
        categorySelect.appendChild(option);
    });

    // Code to submit category and item forms
    let categoryForm = document.getElementById('categoryForm');
    let itemForm = document.getElementById('itemForm');
    let paymentTable = document.getElementById('paymentTable');

    categoryForm.addEventListener('submit', (e) => {
        e.preventDefault();
        let categoryName = document.getElementById('categoryName').value;
        // Send categoryName to backend to add category
        // Refresh categorySelect options if needed
        alert('Category added: ' + categoryName);
    });

    itemForm.addEventListener('submit', (e) => {
        e.preventDefault();
        let categoryId = document.getElementById('categorySelect').value;
        let itemName = document.getElementById('itemName').value;
        let itemPrice = document.getElementById('itemPrice').value;
        // Send categoryId, itemName, itemPrice to backend to add item
        alert('Item added: ' + itemName);
    });

    // Code to fetch and display payment status
    // Assume paymentStatus is an array of payment status objects fetched from the database
    let paymentStatus = [
        { user: 'User 1', amount: 50, status: 'Paid' },
        { user: 'User 2', amount: 30, status: 'Pending' },
        // Add more payment status objects as needed
    ];

    paymentStatus.forEach(status => {
        let row = paymentTable.insertRow(-1);
        let cell1 = row.insertCell(0);
        let cell2 = row.insertCell(1);
        let cell3 = row.insertCell(2);
        cell1.textContent = status.user;
        cell2.textContent = status.amount;
        cell3.textContent = status.status;
    });
});
