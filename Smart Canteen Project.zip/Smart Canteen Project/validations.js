function validation(){

    if(document.Formfill.Name.value==""){   
    document.getElementById("result").innerHTML="Enter Username*";
    return false;
    }
    else if(document.Formfill.Name.value.length<6){
    document.getElementById("result").innerHTML="Username atleast six letter*";
    return false;
    }
    else if(document.Formfill.Email.value==""){
    document.getElementById("result").innerHTML="Enter your Email*";
    return false
    }
    else if(document.Formfill.Password.value==""){
    document.getElementById("result").innerHTML="Enter your Password*";
    return false;
    }
    else if(document.Formfill.Password.value.length<6){
    document.getElementById("result").innerHTML="Password must be 6-digit*";
    return false;
    }
    else if(document.Formfill.CPassword.value==""){
    document.getElementById("result").innerHTML="Enter Confirm Password*";
    return false;
    }
    else if(document.Formfill.CPassword.value!==document.Formfill.Password.value){
    document.getElementById("result").innerHTML="Password does not matched*";
    return false;
    }
    else if(document.Formfill.Password.value == document.Formfill.CPassword.value){
    popup.classList.add("open-slide")
    return false;
    }
}

function validateForm() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }
    return true;
}